#ifndef RMD160_H
#define RMD160_H

void
rmd160_hash_buffer( char *outbuf, const char *buffer, size_t length );

#endif /*RMD160_H*/


