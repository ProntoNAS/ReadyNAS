/* link4.c */

#include <stdio.h>

void ok ( void )
{
  puts ( "OK" );
}
