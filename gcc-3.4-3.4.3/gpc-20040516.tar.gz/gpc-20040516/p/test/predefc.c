/* predefc.c */

#include <stdio.h>

#ifdef __i386

#ifdef __i386__

void OK ( void )
{
  puts ( "OK" );
} /* OK */

#else  /* not __i386__ */

void OK ( void )
{
  puts ( "failed" );
} /* OK */

#endif  /* not __i386__ */

#else  /* not __i386 */

/* No test provided. */

void OK ( void )
{
  puts ( "OK" );
} /* OK */

#endif  /* not __i386 */
