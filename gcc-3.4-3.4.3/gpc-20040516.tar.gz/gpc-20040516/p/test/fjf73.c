void p ( void )
{
  struct foo { int a; } v;
  asm("":"=r"(v.a));
}

int main ( void )
{
}
