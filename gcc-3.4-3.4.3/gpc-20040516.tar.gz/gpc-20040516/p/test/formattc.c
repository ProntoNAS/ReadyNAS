#include <time.h>

typedef long long int UnixTimeType;

int cstrftime (UnixTimeType Time, char *Format, char *Buf, int Size);
int cstrftime (UnixTimeType Time, char *Format, char *Buf, int Size)
{
  time_t seconds = (time_t) Time;
  struct tm *gnu = localtime (&seconds);
  int Res;
  /* cf. the recommendations in (libc)strftime on how to check for errors */
  Buf [0] = 1;
  Res = strftime (Buf, Size, Format, gnu);
  if (Res == 0 && Buf [0] != 0)
    Res = -1;
  return Res;
}
